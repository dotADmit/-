﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    class Account
    {
        private User _user;
        public readonly int AccountNumber;
        private decimal _balance;
        private List<Transaction> _transactionLog;

        public Account(User user, int accountNumber)
        {
            //_balance = 0;
            _transactionLog = new List<Transaction>();

            _user = user;
            AccountNumber = accountNumber;
        }

        public void AddMoney(decimal sum, string details)
        {

        }

        public void WithrawMoney(decimal sum, string details)
        {

        }

        public List<Transaction> TransactionHistory()
        {
            List<Transaction> newTransactionLog = new List<Transaction>();

            newTransactionLog = _transactionLog;

            // _transactionLog => newTransactionLog

            return newTransactionLog;
        }
    }
}
