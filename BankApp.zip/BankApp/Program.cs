﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank sberbank = new Bank("Сбер");
            Account ivanov = new Account()
            sberbank.AddAccount();



            sberbank.PrintAccounts();

            sberbank.PrintTransactionLog(12345678);
        }
    }
}
